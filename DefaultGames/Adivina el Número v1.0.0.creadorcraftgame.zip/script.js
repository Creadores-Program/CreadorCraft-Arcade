let randomNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

const guessInput = document.getElementById('guessInput');
const guessButton = document.getElementById('guessButton');
const message = document.getElementById('message');
const gameImage = document.getElementById('gameImage');

function checkGuess() {
    const userGuess = parseInt(guessInput.value);
    attempts++;

    if (isNaN(userGuess) || userGuess < 1 || userGuess > 100) {
        message.textContent = 'Por favor, introduce un número válido entre 1 y 100.';
    } else if (userGuess === randomNumber) {
        message.textContent = `¡Felicidades! ¡Adivinaste el número ${randomNumber} en ${attempts} intentos!`;
        GameProps.getWinSound().play();
        resetGame();
    } else if (userGuess < randomNumber) {
        message.textContent = 'Demasiado bajo. Intenta de nuevo.';
    } else {
        message.textContent = 'Demasiado alto. Intenta de nuevo.';
    }

    guessInput.value = '';
    guessInput.focus();
}

function resetGame() {
    randomNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    message.textContent = '';
    guessInput.value = '';
}

guessButton.addEventListener('click', checkGuess);

guessInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        checkGuess();
    }
});