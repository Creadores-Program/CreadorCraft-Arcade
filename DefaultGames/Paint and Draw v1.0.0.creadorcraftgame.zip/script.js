const canvas = document.getElementById('drawingCanvas');
const ctx = canvas.getContext('2d');
const colorPicker = document.getElementById('colorPicker');
const brushButton = document.getElementById('brushButton');
const eraserButton = document.getElementById('eraserButton');
const undoButton = document.getElementById('undoButton');
const redoButton = document.getElementById('redoButton');
const clearButton = document.getElementById('clearButton');
const saveButton = document.getElementById('saveButton');
const imageUpload = document.getElementById('imageUpload');
const brushSizeInput = document.getElementById('brushSize');
GameProps.getGameMusic().play();
let drawing = false;
let brushColor = colorPicker.value;
let brushSize = brushSizeInput.value;
let isErasing = false;
let history = [];
let historyStep = -1;

// Resize canvas to fill the screen
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight - 100; //Subtract the height of the controls
}

resizeCanvas();

// Redraw on resize
window.addEventListener('resize', resizeCanvas);

// Function to start drawing
function startDrawing(e) {
    drawing = true;
    draw(e);
}

// Function to draw
function draw(e) {
    if (!drawing) return;

    let x, y;

    if (e.touches) {
        x = e.touches[0].clientX - canvas.offsetLeft;
        y = e.touches[0].clientY - canvas.offsetTop;
    } else {
        x = e.clientX - canvas.offsetLeft;
        y = e.clientY - canvas.offsetTop;
    }

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.strokeStyle = isErasing ? 'white' : brushColor;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
}

// Function to stop drawing
function stopDrawing() {
    drawing = false;
    ctx.beginPath();
    saveHistory();
}

// Save drawing history
function saveHistory() {
    history.push(canvas.toDataURL());
    historyStep++;
    if (historyStep < history.length - 1) {
        history = history.slice(0, historyStep + 1);
    }
}

// Undo function
function undo() {
    if (historyStep > 0) {
        historyStep--;
        const img = new Image();
        img.src = history[historyStep];
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        }
    }
}

// Redo function
function redo() {
    if (historyStep < history.length - 1) {
        historyStep++;
        const img = new Image();
        img.src = history[historyStep];
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        }
    }
}

// Clear function
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    saveHistory();
}

// Save function
function saveCanvas() {
    const image = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    const link = document.createElement('a');
    link.download = 'my_drawing.png';
    link.href = image;
    link.click();
}

// Upload image function
function uploadImage(e) {
    const reader = new FileReader();
    reader.onload = function (event) {
        const img = new Image();
        img.onload = () => {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            saveHistory();
        }
        img.src = event.target.result;
    }
    reader.readAsDataURL(e.target.files[0]);
}

// Event listeners
canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);
canvas.addEventListener('mousemove', draw);

canvas.addEventListener('touchstart', startDrawing);
canvas.addEventListener('touchend', stopDrawing);
canvas.addEventListener('touchcancel', stopDrawing);
canvas.addEventListener('touchmove', draw);

colorPicker.addEventListener('input', () => brushColor = colorPicker.value);
brushButton.addEventListener('click', () => isErasing = false);
eraserButton.addEventListener('click', () => isErasing = true);
undoButton.addEventListener('click', undo);
redoButton.addEventListener('click', redo);
clearButton.addEventListener('click', clearCanvas);
saveButton.addEventListener('click', saveCanvas);
imageUpload.addEventListener('change', uploadImage);
brushSizeInput.addEventListener('input', () => brushSize = brushSizeInput.value);