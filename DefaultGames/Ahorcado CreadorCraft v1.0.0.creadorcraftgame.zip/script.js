const palabras = [
    "arbol", "casa", "perro", "gato", "sol", "luna", "rio", "mar", "cielo", "nube",
    "libro", "mesa", "silla", "puerta", "ventana", "teclado", "raton", "monitor", "telefono", "camara",
    "musica", "arte", "pintura", "escultura", "cine", "teatro", "danza", "poesia", "literatura", "historia",
    "ciencia", "matematicas", "fisica", "quimica", "biologia", "geografia", "economia", "sociologia", "psicologia", "filosofia",
    "futbol", "baloncesto", "tenis", "voleibol", "natacion", "atletismo", "ciclismo", "boxeo", "golf", "ajedrez",
    "rojo", "azul", "verde", "amarillo", "naranja", "morado", "rosa", "blanco", "negro", "gris",
    "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez",
    "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
    "primavera", "verano", "otono", "invierno", "desierto", "selva", "montana", "playa", "ciudad", "pueblo",
    "computadora", "internet", "videojuego", "programa", "aplicacion", "desarrollador", "ingeniero", "arquitecto", "doctor", "profesor",
    "planeta", "galaxia", "universo", "estrella", "satelite", "telescopio", "microscopio", "bacteria", "virus", "celula"
];

let palabraOculta = "";
let palabraGuiones = "";
let letrasUsadas = [];
let vidas = 6;
let imagenesAhorc = ["https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh7FswdyW8gEX-Gd0CkgZw5RmEEyQLsVYWPoVorzSdk6KDhDCl042STnmxcpsZyAoOo43wPw69o7E9PF0G8OqtvzTs4-abi5x09Z_kg8Fg6zDNUAmycJwOFNfjtx1YCM7_muxUoMOdm6P41Qg77NPvx6F5XU3AQ0P2JjejTFjjxjNsO2MtC0qZBPz0Wjw/s320/1686428067351.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjypiQJRxCHoKwVSisRJJrz4pOKKMh4BtdpOIDcs2KSYAcw797HLgxvVut0CcolWt_MbaOCywTS8BXjxM3CtXbth7cCPi9mC8xZ_HI-R7FAIJxjfgLcyDQR4I8wSfeSof9KBQdLLflqo1gRAJAhuoO26vht1sOjrTKHO9f6GI3WoKvlT3w9jEhgntEZ5Q/s320/1686428102551.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgzO3kGoBWb2uHZCWO8sJjGfVuzb1QxnIOaExb9LKPPNEIFQpjuMesyFHjzC02OvnohvzgMrFXFFM4DhRp4etbFd8bk8bdIHu3qwz3pa-Uv2zaNRa27TGRxjdLI7Twjltn2Ndr0EDrV9L9yA4X8ft72JgiUEHrxt40IbTjHPaMyFqLpecBNmUHjCUSz1A/s320/1686428131899.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgIqpCX2fL9CWQUL0LAvEVoWXvNAyB8BYhM7DBz0yULIxHIC4oQT2dL8eWIl82XoWd0Q70tbGPf0SHXu2awDT1GrUmi-91xCWpQYgJxb3quw39JaNVxgl5y5MC9OLKTeerXWw0J7R9Ei91lw_SpcFph_KOCrlwEUBYrx-S-YDyzIkTYG6Ig-SQTQwkOmA/s320/1686428164946.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiuqk61-kdY3g0h8bI1jji2BNGoYptlmj_1fywNQ0cLlAlnGA1TtfqiiDGFL6DD-RfZbmgb6enOOPn3MDWKFmbkKH1wlu3jKg1C1eFtncDnRGtYxg_xy5rHQ4Oxpq26ayDn-GyYVxB5OZzHvUVfT_-EKm0D9wu3l_jJNuhCX1F2DvqS1aFqaLd5tVF1FQ/s320/1686428199747.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiqRPavRr-FcPB2cvMQ4s0dIdo_Oz8py4r8vQjb4K-NWZxemI67xsqFu9LYyACVUIbYr43PHpJYq60HI7l4NkkINLM-FE_yGBi-keYw5ZpySW73FYk42idQ7D4VK0DUvZhiff6LraISicH6o4dDIKySTE-vZmJwCfaUOXNhp_HeIZ3QSiSqWlgImyW1jg/s320/1686428222520.png", "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEij5My2hb6we8csZnopHsVQMQx3BxFIDDbRTrS7ZCNCL7IvbwBf1-HGasmpio_ifyxe2J5jqdnV6wWPtxWHTmtTitLT492C1lwwKZrZDmxJOUuG2P4K5lC_FhWtcvByvHC7hofS4OJMngLiybiXbHUM4_Ax2D3RhABGHqp5P93Gda_U33eD05cCnP8zcQ/s320/1686428249049.png"];

const imagenAhorcado = document.getElementById("ahorcado-imagen");
const palabraOcultaTexto = document.getElementById("palabra-oculta");
const letrasUsadasTexto = document.getElementById("letras-usadas");
const letraInput = document.getElementById("letra-input");
const adivinarButton = document.getElementById("adivinar-button");
const mensajeTexto = document.getElementById("mensaje");

function iniciarJuego() {
    palabraOculta = palabras[Math.floor(Math.random() * palabras.length)].toUpperCase();
    palabraGuiones = "_".repeat(palabraOculta.length);
    letrasUsadas = [];
    vidas = 6;

    actualizarAhorcadoImagen();
    actualizarPalabraOculta();
    actualizarLetrasUsadas();
    actualizarMensaje("");
}

function actualizarAhorcadoImagen() {
    imagenAhorcado.src = imagenesAhorc[6 - vidas];
}

function actualizarPalabraOculta() {
    palabraOcultaTexto.textContent = palabraGuiones.split("").join(" ");
}

function actualizarLetrasUsadas() {
    letrasUsadasTexto.textContent = "Letras usadas: " + letrasUsadas.join(", ");
}

function actualizarMensaje(mensaje) {
    mensajeTexto.textContent = mensaje;
}

function adivinarLetra() {
    const letra = letraInput.value.toUpperCase();
    letraInput.value = "";

    if (letrasUsadas.includes(letra)) {
        actualizarMensaje("Ya has usado esa letra.");
        return;
    }

    letrasUsadas.push(letra);

    if (palabraOculta.includes(letra)) {
        let nuevaPalabraGuiones = "";
        for (let i = 0; i < palabraOculta.length; i++) {
            if (palabraOculta[i] === letra) {
                nuevaPalabraGuiones += letra;
            } else {
                nuevaPalabraGuiones += palabraGuiones[i];
            }
        }
        palabraGuiones = nuevaPalabraGuiones;
        actualizarPalabraOculta();

        if (!palabraGuiones.includes("_")) {
            GameProps.getWinSound().play();
            actualizarMensaje("¡Felicidades! Has adivinado la palabra.");
            setTimeout(iniciarJuego, 3000);
        }
    } else {
        vidas--;
        actualizarAhorcadoImagen();
        actualizarLetrasUsadas();

        if (vidas === 0) {
            actualizarMensaje(`¡Has perdido! La palabra era ${palabraOculta}.`);
            setTimeout(iniciarJuego, 3000);
        } else {
            actualizarMensaje(`Letra incorrecta. Te quedan ${vidas} vidas.`);
        }
    }
}

adivinarButton.addEventListener("click", adivinarLetra);

iniciarJuego();